from itertools import permutations

print( sorted('негнипапинген') )

allPerm = set( permutations('ГЕИННП') )

print( len(allPerm) )
