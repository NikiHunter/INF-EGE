print( 9**13 )
