x = 1
for n in range(3516, 3513, -1):
  x *= 2*n - 1

print( x )