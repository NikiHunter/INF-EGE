s = open('24-228.txt').readline()


digits = '0123456789'
def matchMask( s, startPos, mask ):
  i = startPos
  for k, m in enumerate(mask):
    if i >= len(s): return 0
    if s[i] == m or \
       s[i] in digits and m == '?':
      i +=1
    else:
      return 0
  numLen = len(mask) - 4
  # print( s[startPos:startPos+20] )
  return int( s[startPos+2:startPos+2+numLen] )

nMax = 0
for i in range(len(s)):
  n = matchMask( s, i, 'XX3????78??45XX' )
  if n: print(n)
  nMax = max( nMax, n )

pEven = 1
[ pEven:=pEven*int(d) for d in str(nMax) if int(d) % 2 == 0]
sOdd = sum( int(d) for d in str(nMax) if int(d) % 2 == 1 )

print( nMax, sOdd+pEven )

